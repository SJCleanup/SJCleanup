# SJ Cleanup Platform

A Next.js-based marketplace platform for cleaning services in South Jersey.

## Features

- **Customer Portal** - Book services, view jobs, see before/after photos
- **Worker Portal** - Find available jobs, accept work, upload verification photos
- **Admin Dashboard** - Manage jobs, workers, customers, and review flagged photos
- **Xano Backend Integration** - Full API client for all operations

## Tech Stack

- **Frontend**: Next.js 14 (App Router), React 18, TypeScript
- **Styling**: Tailwind CSS
- **Backend**: Xano (no-code backend)
- **Payments**: Stripe + Stripe Connect (coming soon)
- **Photo Storage**: Cloudinary

## Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Set Up Environment Variables

Copy the example env file:
```bash
cp .env.example .env.local
```

The Xano API URLs are pre-configured. You'll need to add:
- Stripe keys (when ready for payments)
- Cloudinary credentials (for photo uploads)

### 3. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## Project Structure

```
sjcleanup-platform/
├── app/
│   ├── page.tsx           # Landing page
│   ├── layout.tsx         # Root layout
│   ├── globals.css        # Global styles
│   ├── customer/
│   │   └── page.tsx       # Customer dashboard
│   ├── worker/
│   │   └── page.tsx       # Worker dashboard
│   └── admin/
│       └── page.tsx       # Admin dashboard
├── components/            # Reusable UI components
│   ├── ui/               # Base UI components
│   └── layout/           # Layout components
├── lib/
│   ├── xano.ts           # Xano API client
│   └── utils.ts          # Utility functions
├── .env.local            # Environment variables
└── package.json
```

## Pages

| Route | Description |
|-------|-------------|
| `/` | Public landing page |
| `/customer` | Customer dashboard |
| `/worker` | Worker dashboard |
| `/admin` | Admin dashboard (Janine's command center) |

## API Endpoints (Xano)

### Public API
- `POST /check-service-area` - Check if ZIP code is serviceable
- `POST /calculate-price` - Get price quote

### Customer API  
- `POST /customer/signup` - Register new customer
- `POST /customer/book-service` - Book a job
- `GET /customer/jobs` - View customer's jobs
- `GET /customer/view-photos` - View job photos

### Worker API
- `POST /worker/signup` - Register as worker
- `GET /worker/available-jobs` - Find available jobs
- `POST /worker/accept-job` - Accept a job
- `GET /worker/my-jobs` - View assigned jobs
- `POST /worker/upload-photo` - Upload before/after photos
- `GET /worker/my-payouts` - View payment history

### Admin API
- `GET /admin/dashboard` - Full dashboard data
- `GET /admin/stats` - Platform statistics
- `GET /admin/all-jobs` - All jobs
- `GET /admin/workers` - All workers
- `GET /admin/customers` - All customers
- `GET /admin/photos-pending-review` - Flagged photos
- `POST /admin/approve-photo` - Approve a photo
- `POST /admin/reject-photo` - Reject a photo
- `POST /admin/update-worker-status` - Update worker status
- `POST /admin/update-job-status` - Update job status

## Deployment

### Vercel (Recommended)

1. Push to GitHub
2. Import project in Vercel
3. Add environment variables
4. Deploy

```bash
# Push to GitHub
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/sjcleanup-platform.git
git push -u origin main
```

## Development Notes

- The platform uses mock customer/worker IDs for demo purposes
- Authentication system needs to be implemented
- Stripe integration is stubbed but not active
- Cloudinary upload widget needs to be added to worker portal

## Next Steps

1. [ ] Add authentication (customer/worker login)
2. [ ] Implement Stripe checkout for bookings
3. [ ] Add Stripe Connect for worker payouts
4. [ ] Integrate Cloudinary upload widget
5. [ ] Add real-time notifications (Twilio SMS)
6. [ ] Build Facebook Messenger bot integration

## License

Proprietary - SJ Cleanup LLC
