// Xano API Client for SJCleanup

const API_URLS = {
  public: process.env.NEXT_PUBLIC_XANO_PUBLIC_API || '',
  customer: process.env.NEXT_PUBLIC_XANO_CUSTOMER_API || '',
  worker: process.env.NEXT_PUBLIC_XANO_WORKER_API || '',
  admin: process.env.NEXT_PUBLIC_XANO_ADMIN_API || '',
  webhooks: process.env.NEXT_PUBLIC_XANO_WEBHOOKS_API || '',
};

type ApiGroup = keyof typeof API_URLS;

interface FetchOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  body?: Record<string, unknown>;
  headers?: Record<string, string>;
}

class XanoClient {
  private async fetch<T>(
    group: ApiGroup,
    endpoint: string,
    options: FetchOptions = {}
  ): Promise<T> {
    const { method = 'GET', body, headers = {} } = options;
    const baseUrl = API_URLS[group];
    
    if (!baseUrl) {
      throw new Error(`API URL not configured for group: ${group}`);
    }

    const url = `${baseUrl}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`;
    
    const fetchOptions: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
    };

    if (body && method !== 'GET') {
      fetchOptions.body = JSON.stringify(body);
    }

    // For GET requests with body, use query params
    let finalUrl = url;
    if (body && method === 'GET') {
      const params = new URLSearchParams();
      Object.entries(body).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          params.append(key, String(value));
        }
      });
      finalUrl = `${url}?${params.toString()}`;
    }

    const response = await fetch(finalUrl, fetchOptions);
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: 'Unknown error' }));
      throw new Error(error.message || `HTTP error! status: ${response.status}`);
    }

    return response.json();
  }

  // ============ PUBLIC API ============
  async checkServiceArea(zipCode: string) {
    return this.fetch<{ zip_code: string; territories: Territory[] }>(
      'public',
      '/check-service-area',
      { method: 'POST', body: { zip_code: zipCode } }
    );
  }

  async calculatePrice(data: {
    zip_code: string;
    sq_footage: number;
    service_type: string;
    is_rush: boolean;
  }) {
    return this.fetch<PriceQuote>('public', '/calculate-price', {
      method: 'POST',
      body: data,
    });
  }

  // ============ CUSTOMER API ============
  async customerSignup(data: CustomerSignupData) {
    return this.fetch<{ success: boolean; customer: Customer }>(
      'customer',
      '/customer/signup',
      { method: 'POST', body: data }
    );
  }

  async bookService(data: BookServiceData) {
    return this.fetch<{ success: boolean; job: Job; pricing: PriceQuote }>(
      'customer',
      '/customer/book-service',
      { method: 'POST', body: data }
    );
  }

  async getCustomerJobs(customerId: number) {
    return this.fetch<{ jobs: Job[] }>('customer', '/customer/jobs', {
      method: 'GET',
      body: { customer_id: customerId },
    });
  }

  async viewPhotos(jobId: number) {
    return this.fetch<{ job: Job; photos: JobPhoto[] }>(
      'customer',
      '/customer/view-photos',
      { method: 'GET', body: { job_id: jobId } }
    );
  }

  // ============ WORKER API ============
  async workerSignup(data: WorkerSignupData) {
    return this.fetch<{ success: boolean; worker: Worker }>(
      'worker',
      '/worker/signup',
      { method: 'POST', body: data }
    );
  }

  async getAvailableJobs(workerId: number) {
    return this.fetch<{ jobs: Job[] }>('worker', '/worker/available-jobs', {
      method: 'GET',
      body: { worker_id: workerId },
    });
  }

  async acceptJob(jobId: number, workerId: number) {
    return this.fetch<{ success: boolean; job: Job }>(
      'worker',
      '/worker/accept-job',
      { method: 'POST', body: { job_id: jobId, worker_id: workerId } }
    );
  }

  async getWorkerJobs(workerId: number) {
    return this.fetch<{ jobs: Job[]; count: number }>(
      'worker',
      '/worker/my-jobs',
      { method: 'GET', body: { worker_id: workerId } }
    );
  }

  async uploadPhoto(data: UploadPhotoData) {
    return this.fetch<{ success: boolean; photo: JobPhoto }>(
      'worker',
      '/worker/upload-photo',
      { method: 'POST', body: data }
    );
  }

  async getWorkerPayouts(workerId: number) {
    return this.fetch<{ payouts: Payout[]; total_count: number; worker: Worker }>(
      'worker',
      '/worker/my-payouts',
      { method: 'GET', body: { worker_id: workerId } }
    );
  }

  // ============ ADMIN API ============
  async getDashboard() {
    return this.fetch<AdminDashboard>('admin', '/admin/dashboard');
  }

  async getStats() {
    return this.fetch<AdminStats>('admin', '/admin/stats');
  }

  async getAllJobs(filters?: { status?: string; service_type?: string; territory_id?: number }) {
    return this.fetch<{ jobs: Job[]; customers: Customer[]; workers: Worker[]; total_jobs: number }>(
      'admin',
      '/admin/all-jobs',
      { method: 'GET', body: filters }
    );
  }

  async getCustomers() {
    return this.fetch<{ customers: Customer[]; count: number }>(
      'admin',
      '/admin/customers'
    );
  }

  async getWorkers() {
    return this.fetch<{ workers: Worker[]; count: number }>(
      'admin',
      '/admin/workers'
    );
  }

  async getTerritories() {
    return this.fetch<{ territories: Territory[]; count: number }>(
      'admin',
      '/admin/territories'
    );
  }

  async getPhotosPendingReview() {
    return this.fetch<{ photos: JobPhoto[] }>(
      'admin',
      '/admin/photos-pending-review'
    );
  }

  async approvePhoto(photoId: number, approved: boolean, rejectionReason?: string) {
    return this.fetch<{ success: boolean; photo: JobPhoto }>(
      'admin',
      '/admin/approve-photo',
      {
        method: 'POST',
        body: { photo_id: photoId, approved, rejection_reason: rejectionReason || '' },
      }
    );
  }

  async rejectPhoto(photoId: number, rejectionReason: string, reviewedBy: string) {
    return this.fetch<{ success: boolean; photo: JobPhoto }>(
      'admin',
      '/admin/reject-photo',
      {
        method: 'POST',
        body: { photo_id: photoId, rejection_reason: rejectionReason, reviewed_by: reviewedBy },
      }
    );
  }

  async updateWorkerStatus(workerId: number, status: string) {
    return this.fetch<{ success: boolean; worker: Worker }>(
      'admin',
      '/admin/update-worker-status',
      { method: 'POST', body: { worker_id: workerId, status } }
    );
  }

  async updateJobStatus(jobId: number, status: string) {
    return this.fetch<{ success: boolean; job: Job }>(
      'admin',
      '/admin/update-job-status',
      { method: 'POST', body: { job_id: jobId, status } }
    );
  }
}

// Export singleton instance
export const xano = new XanoClient();

// ============ TYPE DEFINITIONS ============

export interface Territory {
  id: number;
  created_at: string;
  name: string;
  zip_codes: string[];
  city: string;
  county: string;
  state: string;
  facebook_group_url: string;
  facebook_group_name: string;
  service_type: 'poop_scoop' | 'commercial_cleaning' | 'both';
  is_active: boolean;
  base_price: number;
  price_per_sqft: number;
  rush_fee_percent: number;
}

export interface Customer {
  id: number;
  created_at: string;
  email: string;
  phone: string;
  first_name: string;
  last_name: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  sq_footage: number;
  notification_pref: 'sms' | 'email' | 'app';
  stripe_customer_id: string;
  status: 'active' | 'inactive' | 'suspended';
  notes: string;
}

export interface Worker {
  id: number;
  created_at: string;
  email: string;
  phone: string;
  first_name: string;
  last_name: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  service_radius_miles: number;
  status: 'applicant' | 'pending_background' | 'background_failed' | 'pending_contract' | 'active' | 'inactive' | 'suspended';
  background_check_id: string;
  background_check_status: string;
  stripe_connect_id: string;
  stripe_connect_status: 'not_started' | 'pending' | 'active' | 'restricted';
  messenger_psid: string;
  contract_signed_at: string;
  avg_rating: number;
  total_jobs_completed: number;
  total_earnings: number;
  service_types: string[];
  notes: string;
}

export interface Job {
  id: number;
  created_at: string;
  customer_id: number;
  worker_id: number | null;
  territory_id: number;
  service_type: 'poop_scoop' | 'commercial_cleaning';
  status: 'pending_worker' | 'assigned' | 'scheduled' | 'in_progress' | 'pending_photo_review' | 'completed' | 'disputed' | 'cancelled' | 'refunded';
  scheduled_date: string;
  scheduled_time: string;
  is_rush: boolean;
  price_customer: number;
  price_worker: number;
  platform_fee: number;
  address: string;
  city: string;
  state: string;
  zip: string;
  sq_footage: number;
  special_instructions: string;
  stripe_payment_intent_id: string;
  stripe_charge_id: string;
  started_at: string;
  completed_at: string;
  subscription_id: number;
  rating: number;
  rating_comment: string;
}

export interface JobPhoto {
  id: number;
  created_at: string;
  job_id: number;
  worker_id: number;
  photo_type: 'before' | 'after';
  cloudinary_url: string;
  cloudinary_public_id: string;
  original_filename: string;
  file_size: number;
  ai_analysis: Record<string, unknown>;
  ai_score: number;
  ai_flagged: boolean;
  ai_flag_reason: string;
  is_ai_generated: boolean;
  manually_reviewed: boolean;
  reviewed_by: string;
  reviewed_at: string;
  approved: boolean | null;
  rejection_reason: string;
  gps_latitude: number;
  gps_longitude: number;
  uploaded_at: string;
}

export interface Payout {
  id: number;
  created_at: string;
  job_id: number;
  worker_id: number;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'cancelled';
  stripe_transfer_id: string;
  stripe_payout_id: string;
  failure_reason: string;
  initiated_at: string;
  completed_at: string;
  notes: string;
}

export interface PriceQuote {
  zip_code: string;
  sq_footage: number;
  service_type: string;
  base_price: number;
  subtotal: number;
  rush_fee: number;
  total: number;
  worker_cut: number;
  platform_fee: number;
}

export interface CustomerSignupData {
  email: string;
  phone: string;
  first_name: string;
  last_name: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  sq_footage?: number;
  notification_pref?: 'sms' | 'email' | 'app';
}

export interface WorkerSignupData {
  email: string;
  phone: string;
  first_name: string;
  last_name: string;
  address?: string;
  city?: string;
  state?: string;
  zip: string;
  service_radius_miles?: number;
  service_types?: string[];
}

export interface BookServiceData {
  customer_id: number;
  service_type: string;
  address: string;
  city: string;
  state: string;
  zip: string;
  sq_footage: number;
  scheduled_date: string;
  scheduled_time: string;
  is_rush?: boolean;
  special_instructions?: string;
}

export interface UploadPhotoData {
  job_id: number;
  worker_id: number;
  photo_type: 'before' | 'after';
  cloudinary_url: string;
  cloudinary_public_id?: string;
  original_filename?: string;
  file_size?: number;
  gps_latitude?: number;
  gps_longitude?: number;
}

export interface AdminDashboard {
  total_jobs: number;
  total_customers: number;
  total_workers: number;
  jobs: Job[];
  customers: Customer[];
  workers: Worker[];
}

export interface AdminStats {
  total_jobs: number;
  completed_jobs: number;
  pending_jobs: number;
  total_customers: number;
  active_workers: number;
  flagged_photos: number;
}
