import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function formatDate(date: string | Date): string {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(new Date(date));
}

export function formatDateTime(date: string | Date): string {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(new Date(date));
}

export function getStatusColor(status: string): string {
  const colors: Record<string, string> = {
    // Job statuses
    pending_worker: 'badge-warning',
    assigned: 'badge-info',
    scheduled: 'badge-info',
    in_progress: 'badge-info',
    pending_photo_review: 'badge-warning',
    completed: 'badge-success',
    disputed: 'badge-error',
    cancelled: 'badge-error',
    refunded: 'badge-error',
    // Worker statuses
    applicant: 'badge-warning',
    pending_background: 'badge-warning',
    background_failed: 'badge-error',
    pending_contract: 'badge-warning',
    active: 'badge-success',
    inactive: 'badge-warning',
    suspended: 'badge-error',
    // Payment statuses
    pending: 'badge-warning',
    processing: 'badge-info',
    failed: 'badge-error',
  };
  return colors[status] || 'badge-info';
}

export function getStatusLabel(status: string): string {
  const labels: Record<string, string> = {
    pending_worker: 'Needs Worker',
    assigned: 'Assigned',
    scheduled: 'Scheduled',
    in_progress: 'In Progress',
    pending_photo_review: 'Review Photos',
    completed: 'Completed',
    disputed: 'Disputed',
    cancelled: 'Cancelled',
    refunded: 'Refunded',
    applicant: 'Applicant',
    pending_background: 'Background Check',
    background_failed: 'Failed Check',
    pending_contract: 'Contract Pending',
    active: 'Active',
    inactive: 'Inactive',
    suspended: 'Suspended',
  };
  return labels[status] || status.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
}
