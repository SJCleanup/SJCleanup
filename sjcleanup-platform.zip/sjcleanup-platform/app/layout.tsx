import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ 
  subsets: ["latin"],
  variable: "--font-geist-sans",
});

export const metadata: Metadata = {
  title: "SJ Cleanup | South Jersey Cleaning Services",
  description: "Professional yard cleanup and commercial cleaning services in South Jersey. Book online, get instant pricing.",
  keywords: ["cleaning services", "yard cleanup", "poop scoop", "South Jersey", "NJ"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} font-sans`}>
        {children}
      </body>
    </html>
  );
}
