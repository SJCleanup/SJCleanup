'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  Sparkles, 
  Calendar, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  DollarSign,
  ArrowRight,
  Camera,
  Briefcase,
  TrendingUp
} from 'lucide-react';
import { xano, Job, Worker } from '@/lib/xano';
import { formatDate, formatCurrency, getStatusColor, getStatusLabel } from '@/lib/utils';

export default function WorkerDashboard() {
  const [myJobs, setMyJobs] = useState<Job[]>([]);
  const [availableJobs, setAvailableJobs] = useState<Job[]>([]);
  const [worker, setWorker] = useState<Worker | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'my-jobs' | 'available'>('my-jobs');

  // For demo, we'll use worker_id = 1 (James Rodriguez)
  const workerId = 1;

  useEffect(() => {
    async function fetchData() {
      try {
        const [jobsData, availableData, payoutsData] = await Promise.all([
          xano.getWorkerJobs(workerId),
          xano.getAvailableJobs(workerId),
          xano.getWorkerPayouts(workerId),
        ]);
        setMyJobs(jobsData.jobs || []);
        setAvailableJobs(availableData.jobs || []);
        setWorker(payoutsData.worker);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const handleAcceptJob = async (jobId: number) => {
    try {
      await xano.acceptJob(jobId, workerId);
      // Refresh jobs
      const [jobsData, availableData] = await Promise.all([
        xano.getWorkerJobs(workerId),
        xano.getAvailableJobs(workerId),
      ]);
      setMyJobs(jobsData.jobs || []);
      setAvailableJobs(availableData.jobs || []);
    } catch (error) {
      console.error('Error accepting job:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">SJ Cleanup</span>
              <span className="text-sm text-gray-500 ml-2">Provider Portal</span>
            </Link>
            <nav className="flex items-center gap-6">
              <Link href="/worker" className="text-sm font-medium text-brand-600">Dashboard</Link>
              <Link href="/worker/payouts" className="text-sm text-gray-600 hover:text-gray-900">Payouts</Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back{worker ? `, ${worker.first_name}` : ''}!
          </h1>
          <p className="text-gray-600 mt-1">Find jobs, track earnings, and manage your schedule.</p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <div className="card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(worker?.total_earnings || 0)}
                </p>
                <p className="text-sm text-gray-500">Total Earnings</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{worker?.total_jobs_completed || 0}</p>
                <p className="text-sm text-gray-500">Jobs Completed</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">
                  {worker?.avg_rating ? `${worker.avg_rating.toFixed(1)}★` : 'N/A'}
                </p>
                <p className="text-sm text-gray-500">Avg Rating</p>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{availableJobs.length}</p>
                <p className="text-sm text-gray-500">Jobs Available</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setActiveTab('my-jobs')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              activeTab === 'my-jobs'
                ? 'bg-brand-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            My Jobs ({myJobs.length})
          </button>
          <button
            onClick={() => setActiveTab('available')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              activeTab === 'available'
                ? 'bg-brand-600 text-white'
                : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Available Jobs ({availableJobs.length})
          </button>
        </div>

        {/* Jobs List */}
        <div className="card">
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin w-8 h-8 border-4 border-brand-600 border-t-transparent rounded-full mx-auto"></div>
              <p className="text-gray-500 mt-4">Loading jobs...</p>
            </div>
          ) : activeTab === 'my-jobs' ? (
            myJobs.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs yet</h3>
                <p className="text-gray-500">Check the Available Jobs tab to find work!</p>
              </div>
            ) : (
              <div className="space-y-4">
                {myJobs.map((job) => (
                  <div key={job.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      {job.status === 'completed' ? (
                        <CheckCircle2 className="w-6 h-6 text-green-600" />
                      ) : job.status === 'pending_photo_review' ? (
                        <Camera className="w-6 h-6 text-yellow-600" />
                      ) : (
                        <Clock className="w-6 h-6 text-blue-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-gray-900">
                          {job.service_type === 'poop_scoop' ? 'Pet Waste Removal' : 'Commercial Cleaning'}
                        </h3>
                        <span className={getStatusColor(job.status)}>
                          {getStatusLabel(job.status)}
                        </span>
                        {job.is_rush && <span className="badge-error">RUSH</span>}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-500 mt-1">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {job.address}, {job.city}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {formatDate(job.scheduled_date)} at {job.scheduled_time}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-green-600">{formatCurrency(job.price_worker)}</p>
                      <p className="text-sm text-gray-500">Your cut</p>
                    </div>
                    {(job.status === 'scheduled' || job.status === 'assigned') && (
                      <Link href={`/worker/job/${job.id}`} className="btn-primary text-sm">
                        <Camera className="w-4 h-4 mr-1" />
                        Upload Photos
                      </Link>
                    )}
                  </div>
                ))}
              </div>
            )
          ) : availableJobs.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs available</h3>
              <p className="text-gray-500">Check back later for new opportunities!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {availableJobs.map((job) => (
                <div key={job.id} className="flex items-center gap-4 p-4 bg-green-50 rounded-xl border border-green-200">
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <DollarSign className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-gray-900">
                        {job.service_type === 'poop_scoop' ? 'Pet Waste Removal' : 'Commercial Cleaning'}
                      </h3>
                      {job.is_rush && <span className="badge-error">RUSH +25%</span>}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-500 mt-1">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {job.city}, {job.state} {job.zip}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {formatDate(job.scheduled_date)} at {job.scheduled_time}
                      </span>
                      <span>{job.sq_footage?.toLocaleString()} sq ft</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(job.price_worker)}</p>
                    <p className="text-sm text-gray-500">Your earnings</p>
                  </div>
                  <button
                    onClick={() => handleAcceptJob(job.id)}
                    className="btn-accent"
                  >
                    Accept Job
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
