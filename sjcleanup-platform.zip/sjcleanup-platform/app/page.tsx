import Link from 'next/link';
import { 
  Sparkles, 
  Clock, 
  Shield, 
  MapPin, 
  CheckCircle2, 
  ArrowRight,
  Dog,
  Building2,
  Star
} from 'lucide-react';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">SJ Cleanup</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#services" className="text-sm text-gray-600 hover:text-gray-900 transition">Services</a>
              <a href="#pricing" className="text-sm text-gray-600 hover:text-gray-900 transition">Pricing</a>
              <a href="#areas" className="text-sm text-gray-600 hover:text-gray-900 transition">Service Areas</a>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/worker" className="text-sm text-gray-600 hover:text-gray-900 transition">
                Become a Provider
              </Link>
              <Link href="/customer" className="btn-primary">
                Book Now
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-brand-100 rounded-full blur-3xl opacity-50 -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-accent-100 rounded-full blur-3xl opacity-50 translate-y-1/2 -translate-x-1/2" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-100 rounded-full text-brand-700 text-sm font-medium mb-6">
                <MapPin className="w-4 h-4" />
                Serving South Jersey
              </div>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                Your yard,{' '}
                <span className="text-brand-600">spotless</span>
                <br />
                in 24 hours
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-lg">
                Professional pet waste removal and yard cleanup services. 
                Book online, get instant pricing, and enjoy a clean yard without lifting a finger.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/customer" className="btn-accent text-lg px-8 py-4">
                  Get Instant Quote
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
                <a href="#services" className="btn-secondary text-lg px-8 py-4">
                  How It Works
                </a>
              </div>
              
              {/* Trust indicators */}
              <div className="flex items-center gap-6 mt-10 pt-10 border-t border-gray-200">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-full bg-gray-200 border-2 border-white" />
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">Trusted by 200+ customers</p>
                </div>
              </div>
            </div>

            {/* Hero Image/Card */}
            <div className="relative animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <div className="bg-gradient-to-br from-brand-500 to-brand-700 rounded-3xl p-8 text-white shadow-2xl">
                <h3 className="text-2xl font-bold mb-6">Quick Price Check</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-brand-100 mb-2">Your ZIP Code</label>
                    <input 
                      type="text" 
                      placeholder="08079"
                      className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-white/50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-brand-100 mb-2">Yard Size (sq ft)</label>
                    <input 
                      type="number" 
                      placeholder="5000"
                      className="w-full px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/50 focus:outline-none focus:ring-2 focus:ring-white/50"
                    />
                  </div>
                  <Link 
                    href="/customer"
                    className="w-full inline-flex items-center justify-center px-6 py-4 bg-white text-brand-700 font-semibold rounded-xl hover:bg-brand-50 transition mt-4"
                  >
                    Get My Price
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Link>
                </div>
                <p className="text-sm text-brand-100 mt-4 text-center">
                  Starting at $35 • No commitment required
                </p>
              </div>
              
              {/* Floating badge */}
              <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-lg p-4 animate-slide-in-right" style={{ animationDelay: '0.5s' }}>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">100% Satisfaction</p>
                    <p className="text-sm text-gray-500">Guaranteed</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Professional cleaning services for homes and businesses across South Jersey
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Poop Scoop */}
            <div className="card hover:shadow-lg transition group">
              <div className="w-14 h-14 bg-brand-100 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition">
                <Dog className="w-7 h-7 text-brand-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Pet Waste Removal</h3>
              <p className="text-gray-600 mb-6">
                Keep your yard clean and safe for your family and pets. We'll thoroughly remove all pet waste, 
                leaving your outdoor space fresh and enjoyable.
              </p>
              <ul className="space-y-3 mb-6">
                {['Weekly, bi-weekly, or one-time service', 'Before/after photo verification', 'Satisfaction guaranteed'].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-gray-700">
                    <CheckCircle2 className="w-5 h-5 text-brand-500 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <p className="text-2xl font-bold text-brand-600">From $35/visit</p>
            </div>

            {/* Commercial */}
            <div className="card hover:shadow-lg transition group">
              <div className="w-14 h-14 bg-accent-100 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition">
                <Building2 className="w-7 h-7 text-accent-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Commercial Cleaning</h3>
              <p className="text-gray-600 mb-6">
                Professional cleaning for offices, retail spaces, and commercial properties. 
                Maintain a pristine environment for your employees and customers.
              </p>
              <ul className="space-y-3 mb-6">
                {['Flexible scheduling', 'Licensed & insured providers', 'Custom cleaning plans'].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-gray-700">
                    <CheckCircle2 className="w-5 h-5 text-accent-500 flex-shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <p className="text-2xl font-bold text-accent-600">Custom Quote</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Book in minutes, enjoy a clean yard by tomorrow</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Book Online',
                description: 'Enter your address, pick a date, and get instant pricing. No phone calls needed.',
                icon: MapPin,
              },
              {
                step: '02',
                title: 'We Clean',
                description: 'A verified service provider arrives at your scheduled time and gets to work.',
                icon: Sparkles,
              },
              {
                step: '03',
                title: 'Verify & Enjoy',
                description: 'Receive before/after photos as proof. Enjoy your spotless yard!',
                icon: CheckCircle2,
              },
            ].map((item, index) => (
              <div key={item.step} className="relative">
                <div className="text-7xl font-bold text-gray-100 absolute -top-4 left-0">{item.step}</div>
                <div className="relative pt-8">
                  <div className="w-12 h-12 bg-brand-100 rounded-xl flex items-center justify-center mb-4">
                    <item.icon className="w-6 h-6 text-brand-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
                {index < 2 && (
                  <div className="hidden md:block absolute top-1/2 right-0 translate-x-1/2 -translate-y-1/2">
                    <ArrowRight className="w-6 h-6 text-gray-300" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20 bg-brand-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            {[
              { icon: Shield, title: 'Background Checked', desc: 'All providers are verified' },
              { icon: Clock, title: 'Same-Day Available', desc: 'Rush service when you need it' },
              { icon: CheckCircle2, title: '100% Guarantee', desc: 'Not happy? We\'ll make it right' },
            ].map((item) => (
              <div key={item.title} className="flex flex-col items-center">
                <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mb-4">
                  <item.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-brand-100">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section id="areas" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Service Areas</h2>
            <p className="text-xl text-gray-600">Currently serving these South Jersey counties</p>
          </div>
          <div className="flex flex-wrap justify-center gap-4">
            {['Salem County', 'Gloucester County', 'Cumberland County', 'Camden County', 'Burlington County'].map((area) => (
              <div key={area} className="px-6 py-3 bg-gray-100 rounded-full text-gray-700 font-medium">
                {area}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Ready for a cleaner yard?</h2>
          <p className="text-xl text-gray-600 mb-8">
            Join hundreds of happy customers in South Jersey. Book your first cleanup today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/customer" className="btn-accent text-lg px-8 py-4">
              Book Now – From $35
            </Link>
            <Link href="/worker" className="btn-secondary text-lg px-8 py-4">
              Become a Provider
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold">SJ Cleanup</span>
              </div>
              <p className="text-gray-400 text-sm">
                Professional cleaning services for South Jersey homes and businesses.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-white transition">Pet Waste Removal</a></li>
                <li><a href="#" className="hover:text-white transition">Commercial Cleaning</a></li>
                <li><a href="#" className="hover:text-white transition">One-Time Cleanup</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#" className="hover:text-white transition">About Us</a></li>
                <li><Link href="/worker" className="hover:text-white transition">Become a Provider</Link></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>janine@sjcleanup.com</li>
                <li>South Jersey, NJ</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400 text-sm">
            <p>© 2026 SJ Cleanup LLC. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
