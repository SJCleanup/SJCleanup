'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { 
  Sparkles, 
  Users, 
  Briefcase, 
  DollarSign,
  MapPin,
  Camera,
  CheckCircle2,
  XCircle,
  Clock,
  AlertTriangle,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { xano, AdminStats, Job, Customer, Worker, JobPhoto } from '@/lib/xano';
import { formatDate, formatCurrency, getStatusColor, getStatusLabel } from '@/lib/utils';

export default function AdminDashboard() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [flaggedPhotos, setFlaggedPhotos] = useState<JobPhoto[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'jobs' | 'workers' | 'customers' | 'photos'>('overview');

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    setLoading(true);
    try {
      const [statsData, jobsData, customersData, workersData, photosData] = await Promise.all([
        xano.getStats(),
        xano.getAllJobs(),
        xano.getCustomers(),
        xano.getWorkers(),
        xano.getPhotosPendingReview(),
      ]);
      setStats(statsData);
      setJobs(jobsData.jobs || []);
      setCustomers(customersData.customers || []);
      setWorkers(workersData.workers || []);
      setFlaggedPhotos(photosData.photos || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleApprovePhoto = async (photoId: number) => {
    try {
      await xano.approvePhoto(photoId, true);
      fetchData();
    } catch (error) {
      console.error('Error approving photo:', error);
    }
  };

  const handleRejectPhoto = async (photoId: number) => {
    const reason = prompt('Enter rejection reason:');
    if (reason) {
      try {
        await xano.rejectPhoto(photoId, reason, 'Janine');
        fetchData();
      } catch (error) {
        console.error('Error rejecting photo:', error);
      }
    }
  };

  const handleUpdateWorkerStatus = async (workerId: number, status: string) => {
    try {
      await xano.updateWorkerStatus(workerId, status);
      fetchData();
    } catch (error) {
      console.error('Error updating worker:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2">
                <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold text-gray-900">SJ Cleanup</span>
              </Link>
              <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium">
                Admin
              </span>
            </div>
            <div className="flex items-center gap-4">
              <button onClick={fetchData} className="p-2 hover:bg-gray-100 rounded-lg transition">
                <RefreshCw className={`w-5 h-5 text-gray-600 ${loading ? 'animate-spin' : ''}`} />
              </button>
              <div className="text-sm text-gray-600">
                Welcome, <span className="font-semibold">Janine</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex gap-6">
            {[
              { id: 'overview', label: 'Overview', icon: Sparkles },
              { id: 'jobs', label: 'Jobs', icon: Briefcase },
              { id: 'workers', label: 'Workers', icon: Users },
              { id: 'customers', label: 'Customers', icon: Users },
              { id: 'photos', label: 'Photo Review', icon: Camera, badge: flaggedPhotos.length },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`flex items-center gap-2 py-4 border-b-2 transition ${
                  activeTab === tab.id
                    ? 'border-brand-600 text-brand-600'
                    : 'border-transparent text-gray-600 hover:text-gray-900'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
                {tab.badge && tab.badge > 0 && (
                  <span className="px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">
                    {tab.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading && !stats ? (
          <div className="text-center py-20">
            <div className="animate-spin w-12 h-12 border-4 border-brand-600 border-t-transparent rounded-full mx-auto"></div>
            <p className="text-gray-500 mt-4">Loading dashboard...</p>
          </div>
        ) : activeTab === 'overview' ? (
          <>
            {/* Stats Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <div className="card bg-gradient-to-br from-brand-500 to-brand-600 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-brand-100">Total Jobs</p>
                    <p className="text-4xl font-bold mt-1">{stats?.total_jobs || 0}</p>
                  </div>
                  <Briefcase className="w-12 h-12 opacity-20" />
                </div>
              </div>

              <div className="card bg-gradient-to-br from-green-500 to-green-600 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Completed</p>
                    <p className="text-4xl font-bold mt-1">{stats?.completed_jobs || 0}</p>
                  </div>
                  <CheckCircle2 className="w-12 h-12 opacity-20" />
                </div>
              </div>

              <div className="card bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Active Workers</p>
                    <p className="text-4xl font-bold mt-1">{stats?.active_workers || 0}</p>
                  </div>
                  <Users className="w-12 h-12 opacity-20" />
                </div>
              </div>

              <div className="card bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Customers</p>
                    <p className="text-4xl font-bold mt-1">{stats?.total_customers || 0}</p>
                  </div>
                  <Users className="w-12 h-12 opacity-20" />
                </div>
              </div>
            </div>

            {/* Alerts */}
            {(stats?.pending_jobs || 0) > 0 && (
              <div className="card bg-yellow-50 border-yellow-200 mb-6">
                <div className="flex items-center gap-3">
                  <AlertTriangle className="w-6 h-6 text-yellow-600" />
                  <div>
                    <p className="font-semibold text-yellow-800">
                      {stats?.pending_jobs} jobs need workers
                    </p>
                    <p className="text-sm text-yellow-700">
                      Consider posting to Facebook groups to recruit more providers.
                    </p>
                  </div>
                  <button 
                    onClick={() => setActiveTab('jobs')}
                    className="ml-auto text-yellow-700 hover:text-yellow-800 font-medium text-sm"
                  >
                    View Jobs →
                  </button>
                </div>
              </div>
            )}

            {flaggedPhotos.length > 0 && (
              <div className="card bg-red-50 border-red-200 mb-6">
                <div className="flex items-center gap-3">
                  <Camera className="w-6 h-6 text-red-600" />
                  <div>
                    <p className="font-semibold text-red-800">
                      {flaggedPhotos.length} photos need review
                    </p>
                    <p className="text-sm text-red-700">
                      AI flagged these photos for manual verification before payout.
                    </p>
                  </div>
                  <button 
                    onClick={() => setActiveTab('photos')}
                    className="ml-auto text-red-700 hover:text-red-800 font-medium text-sm"
                  >
                    Review Photos →
                  </button>
                </div>
              </div>
            )}

            {/* Recent Activity */}
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="card">
                <h3 className="font-bold text-gray-900 mb-4">Recent Jobs</h3>
                <div className="space-y-3">
                  {jobs.slice(0, 5).map((job) => (
                    <div key={job.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{job.address}</p>
                        <p className="text-sm text-gray-500">{formatDate(job.scheduled_date)}</p>
                      </div>
                      <span className={getStatusColor(job.status)}>
                        {getStatusLabel(job.status)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card">
                <h3 className="font-bold text-gray-900 mb-4">Workers</h3>
                <div className="space-y-3">
                  {workers.slice(0, 5).map((worker) => (
                    <div key={worker.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-10 h-10 bg-brand-100 rounded-full flex items-center justify-center">
                        <span className="font-semibold text-brand-600">
                          {worker.first_name[0]}{worker.last_name[0]}
                        </span>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">
                          {worker.first_name} {worker.last_name}
                        </p>
                        <p className="text-sm text-gray-500">
                          {worker.total_jobs_completed} jobs • {formatCurrency(worker.total_earnings)}
                        </p>
                      </div>
                      <span className={getStatusColor(worker.status)}>
                        {getStatusLabel(worker.status)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        ) : activeTab === 'jobs' ? (
          <div className="card">
            <h2 className="text-xl font-bold text-gray-900 mb-6">All Jobs</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-medium text-gray-600">ID</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Service</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Location</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Price</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Worker</th>
                  </tr>
                </thead>
                <tbody>
                  {jobs.map((job) => (
                    <tr key={job.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4 font-mono text-sm">#{job.id}</td>
                      <td className="py-3 px-4">
                        {job.service_type === 'poop_scoop' ? 'Pet Waste' : 'Commercial'}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4 text-gray-400" />
                          {job.city}, {job.zip}
                        </div>
                      </td>
                      <td className="py-3 px-4">{formatDate(job.scheduled_date)}</td>
                      <td className="py-3 px-4">
                        <span className={getStatusColor(job.status)}>
                          {getStatusLabel(job.status)}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-medium">{formatCurrency(job.price_customer)}</td>
                      <td className="py-3 px-4">
                        {job.worker_id ? `Worker #${job.worker_id}` : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'workers' ? (
          <div className="card">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Workers</h2>
            <div className="space-y-4">
              {workers.map((worker) => (
                <div key={worker.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                  <div className="w-14 h-14 bg-brand-100 rounded-xl flex items-center justify-center">
                    <span className="text-xl font-bold text-brand-600">
                      {worker.first_name[0]}{worker.last_name[0]}
                    </span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-gray-900">
                        {worker.first_name} {worker.last_name}
                      </h3>
                      <span className={getStatusColor(worker.status)}>
                        {getStatusLabel(worker.status)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">{worker.email} • {worker.phone}</p>
                    <p className="text-sm text-gray-500">
                      {worker.city}, {worker.zip} • {worker.service_radius_miles}mi radius
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-gray-900">{worker.total_jobs_completed} jobs</p>
                    <p className="text-sm text-green-600">{formatCurrency(worker.total_earnings)} earned</p>
                    <p className="text-sm text-yellow-600">
                      {worker.avg_rating ? `${worker.avg_rating.toFixed(1)}★` : 'No rating'}
                    </p>
                  </div>
                  <div className="flex flex-col gap-2">
                    {worker.status === 'pending_background' && (
                      <button
                        onClick={() => handleUpdateWorkerStatus(worker.id, 'active')}
                        className="btn-primary text-sm"
                      >
                        Activate
                      </button>
                    )}
                    {worker.status === 'active' && (
                      <button
                        onClick={() => handleUpdateWorkerStatus(worker.id, 'suspended')}
                        className="btn-secondary text-sm text-red-600"
                      >
                        Suspend
                      </button>
                    )}
                    {worker.status === 'suspended' && (
                      <button
                        onClick={() => handleUpdateWorkerStatus(worker.id, 'active')}
                        className="btn-secondary text-sm"
                      >
                        Reactivate
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : activeTab === 'customers' ? (
          <div className="card">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Customers</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Customer</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Contact</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Location</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Yard Size</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {customers.map((customer) => (
                    <tr key={customer.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <p className="font-medium text-gray-900">
                          {customer.first_name} {customer.last_name}
                        </p>
                      </td>
                      <td className="py-3 px-4">
                        <p className="text-sm">{customer.email}</p>
                        <p className="text-sm text-gray-500">{customer.phone}</p>
                      </td>
                      <td className="py-3 px-4">
                        <p className="text-sm">{customer.address}</p>
                        <p className="text-sm text-gray-500">{customer.city}, {customer.zip}</p>
                      </td>
                      <td className="py-3 px-4">
                        {customer.sq_footage?.toLocaleString()} sq ft
                      </td>
                      <td className="py-3 px-4">
                        <span className={getStatusColor(customer.status)}>
                          {getStatusLabel(customer.status)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : activeTab === 'photos' ? (
          <div className="card">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Photos Pending Review</h2>
            {flaggedPhotos.length === 0 ? (
              <div className="text-center py-12">
                <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900">All caught up!</h3>
                <p className="text-gray-500">No photos need review right now.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {flaggedPhotos.map((photo) => (
                  <div key={photo.id} className="border rounded-xl overflow-hidden">
                    <div className="aspect-video bg-gray-200 relative">
                      <img 
                        src={photo.cloudinary_url} 
                        alt={`Job ${photo.job_id} ${photo.photo_type}`}
                        className="w-full h-full object-cover"
                      />
                      <span className={`absolute top-2 left-2 px-2 py-1 rounded text-xs font-medium ${
                        photo.photo_type === 'before' ? 'bg-blue-500 text-white' : 'bg-green-500 text-white'
                      }`}>
                        {photo.photo_type.toUpperCase()}
                      </span>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <p className="font-medium">Job #{photo.job_id}</p>
                        <span className="badge-warning">AI Score: {photo.ai_score}</span>
                      </div>
                      {photo.ai_flag_reason && (
                        <p className="text-sm text-red-600 mb-3">
                          ⚠️ {photo.ai_flag_reason}
                        </p>
                      )}
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleApprovePhoto(photo.id)}
                          className="flex-1 btn-primary text-sm"
                        >
                          <CheckCircle2 className="w-4 h-4 mr-1" />
                          Approve
                        </button>
                        <button
                          onClick={() => handleRejectPhoto(photo.id)}
                          className="flex-1 btn-secondary text-sm text-red-600"
                        >
                          <XCircle className="w-4 h-4 mr-1" />
                          Reject
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : null}
      </main>
    </div>
  );
}
